# basic-structures

`basic-structures` is the study realization of doubly linked list (as queue) and binary search tree.

## Installation
To install this package next packages should be installed:
- pip
- wheel

#### Install From Source

```bash
$ git clone https://github.com/ShuleshkoAndrew/basic_structures.git
$ cd basic_structures
$ pip install ./dist/basic_structures-0.0.2.tar.gz
```


    
